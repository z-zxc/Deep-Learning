import os
import glob
root = os.getcwd()
print('cwd=', root)
for subset in ['train', 'valid', 'test']:
    img_dir = os.path.join(root, 'dataset', subset, 'images')
    lbl_dir = os.path.join(root, 'dataset', subset, 'labels')
    print('\nsubset', subset)
    print(' images exist', os.path.isdir(img_dir), 'labels exist', os.path.isdir(lbl_dir))
    if os.path.isdir(img_dir):
        imgs = glob.glob(os.path.join(img_dir, '*'))
        print('  num images', len(imgs), 'example image', imgs[:3])
    if os.path.isdir(lbl_dir):
        lbls = glob.glob(os.path.join(lbl_dir, '*.txt'))
        print('  num labels', len(lbls), 'example label', lbls[:3])
        bad = []
        classes = set()
        for f in lbls[:200]:
            with open(f, 'r', encoding='utf-8', errors='ignore') as h:
                for line in h:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split()
                    if len(parts) < 5:
                        bad.append((f, line))
                        continue
                    try:
                        c = int(parts[0])
                    except ValueError:
                        bad.append((f, line))
                        continue
                    classes.add(c)
                    if c < 0 or c > 2:
                        bad.append((f, line))
        print('  classes seen sample', sorted(classes))
        print('  sample bad lines', bad[:5])

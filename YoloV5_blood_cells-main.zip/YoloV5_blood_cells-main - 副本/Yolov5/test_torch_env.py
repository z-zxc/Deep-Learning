import torch
print('torch', torch.__version__)
print('cuda_available', torch.cuda.is_available())
print('cuda_version', getattr(torch.version, 'cuda', None))
if torch.cuda.is_available():
    x = torch.randn(1).cuda()
    print('tensor on', x.device)
else:
    x = torch.randn(1)
    print('tensor on', x.device)

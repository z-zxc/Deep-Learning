#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
修复训练结果加载和可视化的问题
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def load_training_results():
    """加载训练结果，处理列名空格问题"""
    results_files = {
        'YOLOv5n': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp/results.csv',
        'YOLOv5s': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp2/results.csv',
        'YOLOv5m': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp3/results.csv',
        'YOLOv5l': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp4/results.csv'
    }
    
    training_results = {}
    for model_name, results_file in results_files.items():
        file_path = Path(results_file)
        if file_path.exists():
            try:
                # 使用skipinitialspace=True处理列名前的空格
                df = pd.read_csv(results_file, skipinitialspace=True, sep=',', encoding='utf-8')
                # 手动清理列名
                df.columns = df.columns.str.strip()
                
                print(f"{model_name} 列名: {list(df.columns)}")
                
                # 检查必要的列是否存在
                required_cols = ['epoch', 'metrics/precision', 'metrics/recall', 'metrics/mAP_0.5', 'metrics/mAP_0.5:0.95']
                missing_cols = [col for col in required_cols if col not in df.columns]
                
                if missing_cols:
                    print(f"警告：{model_name} 缺少以下列: {missing_cols}")
                else:
                    training_results[model_name] = df
                    print(f"{model_name} 训练结果加载成功，共 {len(df)} 个epoch")
                    
            except Exception as e:
                print(f"错误：加载 {model_name} 失败: {str(e)}")
        else:
            print(f"警告：{results_file} 不存在")
    
    return training_results

def plot_training_curves(training_results, metrics):
    """绘制训练曲线，添加完善的错误处理"""
    if not training_results:
        print("错误：没有加载到任何训练结果数据")
        return
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    axes = axes.ravel()
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
    
    for idx, metric in enumerate(metrics):
        ax = axes[idx]
        has_data = False
        
        for model_idx, (model_name, df) in enumerate(training_results.items()):
            # 检查epoch列是否存在
            if 'epoch' not in df.columns:
                print(f"警告: {model_name} 缺少 'epoch' 列")
                continue
            # 检查指标列是否存在
            if metric not in df.columns:
                print(f"警告: {model_name} 缺少 '{metric}' 列")
                continue
            
            ax.plot(df['epoch'], df[metric], label=model_name, 
                   color=colors[model_idx], linewidth=2)
            has_data = True
        
        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=12)
        ax.set_title(f'{metric.replace("_", " ").title()} During Training', 
                    fontsize=14, fontweight='bold')
        
        if has_data:
            ax.legend(loc='best', fontsize=10)
        ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('training_curves.png', dpi=300, bbox_inches='tight')
    plt.show()

def main():
    print("=" * 60)
    print("加载训练结果...")
    print("=" * 60)
    
    # 加载训练结果
    training_results = load_training_results()
    
    print("\n" + "=" * 60)
    print(f"成功加载 {len(training_results)} 个模型的训练结果")
    print("=" * 60)
    
    # 绘制训练曲线
    if training_results:
        metrics_to_plot = ['metrics/precision', 'metrics/recall', 
                          'metrics/mAP_0.5', 'metrics/mAP_0.5:0.95']
        
        print("\n绘制训练曲线...")
        plot_training_curves(training_results, metrics_to_plot)
        print("训练曲线已保存到 training_curves.png")
    else:
        print("警告：没有可用的训练结果数据")

if __name__ == '__main__':
    main()

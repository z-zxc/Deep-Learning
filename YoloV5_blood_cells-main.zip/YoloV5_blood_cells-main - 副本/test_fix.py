#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

# 加载训练结果
results = {
    'YOLOv5n': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp/results.csv',
    'YOLOv5s': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp2/results.csv',
    'YOLOv5m': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp3/results.csv',
    'YOLOv5l': 'YoloV5_blood_cells-main/Yolov5/runs/train/exp4/results.csv'
}

training_results = {}
for model_name, filepath in results.items():
    if Path(filepath).exists():
        df = pd.read_csv(filepath, skipinitialspace=True)
        df.columns = df.columns.str.strip()
        training_results[model_name] = df
        print(f'{model_name}: epoch列存在 = {"epoch" in df.columns}')
        print(f'  列名: {list(df.columns)[:5]}...')

# 测试绘制功能
if training_results:
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
    for i, (model_name, df) in enumerate(training_results.items()):
        ax.plot(df['epoch'], df['metrics/mAP_0.5'], label=model_name, color=colors[i])
    ax.legend()
    plt.savefig('test_plot.png')
    print('\n测试绘图成功，已保存到 test_plot.png')
